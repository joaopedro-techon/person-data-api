"""Monta o dataset normalizado e fiel (entra no HTML como __DATA__).

Contratos:
  - specs/.../contracts/build-data-contract.md
  - specs/.../contracts/column-grammar.md
  - specs/.../data-model.md
"""

from datetime import date, datetime

from column_grammar import parse_coluna, rotulo_manutencao

_TRUE = {"sim", "s", "true", "1", "yes", "y"}


def _parse_int(valor, contexto, avisos):
    s = (valor or "").strip()
    if s == "":
        return 0
    try:
        return int(s)
    except ValueError:
        try:
            return int(float(s.replace(".", "").replace(",", ".")))
        except ValueError:
            _aviso(avisos, f"Valor inteiro inválido em {contexto}: '{s}' (tratado como 0).")
            return 0


def _parse_date(valor, contexto, avisos):
    s = (valor or "").strip()
    if s == "":
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        _aviso(avisos, f"Data inválida em {contexto}: '{s}' (ignorada).")
        return None


def _fmt_date(d):
    return d.strftime("%d/%m/%Y") if d else ""


def _aviso(avisos, msg):
    if msg not in avisos:
        avisos.append(msg)


def construir_dataset(header, linhas, avisos_iniciais=None):
    avisos = list(avisos_iniciais or [])

    # 1) Interpretar colunas (uma vez).
    colunas = [(nome, parse_coluna(nome)) for nome in header]
    for nome, info in colunas:
        if info["kind"] == "desconhecida":
            _aviso(avisos, f"Coluna não reconhecida pela gramática: '{nome}' ({info['motivo']}).")

    # 2) Ordem dos tipos de manutenção = ordem de aparição das colunas.
    tipos, vistos = [], set()
    for nome, info in colunas:
        if info["kind"] == "manutencao":
            chave = info["manutencao"]
            if chave not in vistos:
                vistos.add(chave)
                tipos.append({"chave": chave, "rotulo": rotulo_manutencao(chave)})

    todas_datas = []
    produtos = []

    for linha in linhas:
        def g(nome):
            return linha.get(nome, "")

        custodia = g("sig3stm_cuso_opcr").strip()
        familia = g("nom_fami_prod").strip()
        classificacao = g("classificacao").strip()
        if not custodia:
            custodia = "Sem custódia"
            _aviso(avisos, "Produto sem custódia (sig3stm_cuso_opcr vazio) agrupado em 'Sem custódia'.")
        if not familia:
            familia = "Sem família"
            _aviso(avisos, "Produto sem família (nom_fami_prod vazio) agrupado em 'Sem família'.")
        if not classificacao:
            classificacao = "Sem classificação"
            _aviso(avisos, "Produto sem classificação agrupado em 'Sem classificação'.")

        responsabilidade = g("responsabilidade").strip()
        is_disf = responsabilidade.upper() != "PF"
        nome_prod = g("nom_prod_finn").strip()
        ctx = nome_prod or custodia

        # acumuladores por manutenção
        acc = {}

        def slot(chave):
            return acc.setdefault(chave, {
                "mod_qty": 0, "leg_qty": 0, "mod_date": None, "leg_date": None,
                "mod_pj": 0, "recortes": {},
            })

        for nome, info in colunas:
            if info["kind"] != "manutencao":
                continue
            valor = g(nome)
            s = slot(info["manutencao"])
            env = info["ambiente"]
            if info["rectype"] is None:
                if info["campo"] == "quantidade":
                    q = _parse_int(valor, f"{ctx}/{nome}", avisos)
                    if env == "moderno":
                        s["mod_qty"] = q
                    else:
                        s["leg_qty"] = q
                else:  # ultima_data
                    d = _parse_date(valor, f"{ctx}/{nome}", avisos)
                    if d:
                        todas_datas.append(d)
                    if env == "moderno":
                        s["mod_date"] = d
                    else:
                        s["leg_date"] = d
            else:
                key = (env, info["rectype"], info["rotulo"])
                rec = s["recortes"].setdefault(key, {
                    "tipo": info["rectype"], "rotulo": info["rotulo"],
                    "ambiente": env, "pj": info["is_pj"], "qtd": None, "data": None,
                })
                if info["campo"] == "quantidade":
                    q = _parse_int(valor, f"{ctx}/{nome}", avisos)
                    rec["qtd"] = q
                    if info["is_pj"] and env == "moderno":
                        s["mod_pj"] += q
                else:
                    d = _parse_date(valor, f"{ctx}/{nome}", avisos)
                    if d:
                        todas_datas.append(d)
                    rec["data"] = d

        # consolida manutenções
        manut = {}
        datas_produto = []
        for chave, s in acc.items():
            mod_total = s["mod_qty"]
            mod_pj = s["mod_pj"]
            if is_disf:
                mod_pj = mod_total
            if mod_pj > mod_total:
                _aviso(avisos, f"{ctx}/{chave}: moderno PJ ({mod_pj}) > total moderno ({mod_total}); ajustado.")
                mod_pj = mod_total
            mod_pf = mod_total - mod_pj
            if s["mod_date"]:
                datas_produto.append(s["mod_date"])
            if s["leg_date"]:
                datas_produto.append(s["leg_date"])
            recortes = [
                {
                    "tipo": r["tipo"], "rotulo": r["rotulo"], "ambiente": r["ambiente"],
                    "pj": r["pj"], "qtd": r["qtd"], "data": _fmt_date(r["data"]),
                }
                for r in s["recortes"].values()
            ]
            manut[chave] = {
                "modPF": mod_pf, "modPJ": mod_pj, "leg": s["leg_qty"],
                "dataMod": _fmt_date(s["mod_date"]), "dataLeg": _fmt_date(s["leg_date"]),
                "recortes": recortes,
            }

        ops = _parse_int(g("quantidade_operacoes"), f"{ctx}/quantidade_operacoes", avisos)
        ops_atv = _parse_int(g("quantidade_operacoes_ativas"), f"{ctx}/quantidade_operacoes_ativas", avisos)
        ops_canc = _parse_int(g("quantidade_operacoes_canceladas"), f"{ctx}/quantidade_operacoes_canceladas", avisos)
        ops_liq = _parse_int(g("quantidade_operacoes_liquidadas"), f"{ctx}/quantidade_operacoes_liquidadas", avisos)
        data_contr = _parse_date(g("ultima_data_contratacao"), f"{ctx}/ultima_data_contratacao", avisos)
        if data_contr:
            todas_datas.append(data_contr)
        status = g("status_operacao").strip()
        ativo = ops_atv > 0 or "ATIV" in status.upper()
        contr = g("contratacao_2026").strip().lower() in _TRUE

        produtos.append({
            "custodia": custodia, "nome": nome_prod, "familia": familia,
            "classificacao": classificacao, "responsabilidade": responsabilidade,
            "codigo": g("cod_prod_finn").strip(), "isDisf": is_disf,
            "ops": ops, "opsAtv": ops_atv, "opsCanc": ops_canc, "opsLiq": ops_liq,
            "lastContr": _fmt_date(data_contr), "contr": contr, "ativo": ativo,
            "status": status, "manut": manut, "_datas": datas_produto,
        })

    # 3) referenceDate = maior data observada (determinístico a partir do CSV).
    ref = max(todas_datas) if todas_datas else None

    # 4) last / lastStale por produto, relativos ao ref.
    for p in produtos:
        datas = p.pop("_datas")
        ult = max(datas) if datas else None
        p["last"] = _fmt_date(ult)
        p["lastStale"] = bool(ref and ult and (ref - ult).days > 180)

    # 5) Ocultar manutenções sem NENHUMA solicitação (quantidade zero e datas
    #    nulas em todos os produtos). Mantém o tipo se houver qualquer atividade.
    ativos = set()
    for p in produtos:
        for chave, mm in p["manut"].items():
            if (mm["modPF"] + mm["modPJ"] + mm["leg"]) > 0 or mm["dataMod"] or mm["dataLeg"]:
                ativos.add(chave)
    ocultos = [t["rotulo"] for t in tipos if t["chave"] not in ativos]
    if ativos:  # guarda: se nada tiver atividade, não esvazia o relatório
        tipos = [t for t in tipos if t["chave"] in ativos]
        for p in produtos:
            p["manut"] = {k: v for k, v in p["manut"].items() if k in ativos}
    else:
        ocultos = []

    return {
        "referenceDate": ref.isoformat() if ref else None,
        "tipos": tipos,
        "produtos": produtos,
        "ocultos": ocultos,
        "avisos": avisos,
    }
