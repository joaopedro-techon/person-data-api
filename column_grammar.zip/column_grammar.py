"""Interpretação determinística dos nomes de coluna do CSV.

Contrato: specs/001-gerador-relatorio-mosaico/contracts/column-grammar.md

Gramática (colunas de manutenção):
    <campo>_<manutencao>_<ambiente>[_<recorte>]
    campo      = quantidade | ultima_data
    ambiente   = moderno | moderna | legado   (normalizado: moderno|legado)
    recorte    = origem_<...> | sigla_<...>    (opcional); contém 'pj' => parcela PJ
"""

# Colunas fixas (não passam pela gramática de manutenção).
COLUNAS_FIXAS = {
    "sig3stm_cuso_opcr",
    "responsabilidade",
    "cod_prod_finn",
    "cod_fami_prod",
    "nom_prod_finn",
    "quantidade_operacoes",
    "quantidade_operacoes_ativas",
    "quantidade_operacoes_liquidadas",
    "quantidade_operacoes_canceladas",
    "ultima_data_contratacao",
    "contratacao_2026",
    "status_operacao",
    "cod_clas_fami_prod",
    "nom_fami_prod",
    "classificacao",
}

_ENV = {"moderno": "moderno", "moderna": "moderno", "legado": "legado"}

# Rótulos curados (acentuação/nome amigável). Fallback = de-snake_case capitalizado.
_LABELS = {
    "cancelamento": "Cancelamento",
    "amortizacao": "Amortização",
    "abatimento_titulo": "Abatimento de título",
    "alteracao_cobranca": "Alteração de cobrança",
    "alteracao_dados_cobranca": "Alteração de dados de cobrança",
    "alteracao_dados_liberacao": "Alteração de dados de liberação",
    "alteracao_dados_cadastrais": "Alteração de dados cadastrais",
    "alteracao_endereco": "Alteração de endereço",
    "alteracao_vencimento_titulo": "Alteração de vencimento de título",
    "alteracao_vencimento_cheque": "Alteração de vencimento de cheque",
    "bloqueio_cobranca": "Bloqueio de cobrança",
    "desbloqueio_cobranca": "Desbloqueio de cobrança",
    "liquidacao_garantia": "Liquidação de garantia",
    "substituicao_garantia": "Substituição de garantia",
    "estorno": "Estorno",
    "reversao": "Reversão",
    "repactuacao": "Repactuação",
    "portabilidade": "Portabilidade",
    "formulario_portabilidade": "Formulário de portabilidade",
    "segunda_via_boleto": "2ª via de boleto",
    "memoria_calculo": "Memória de cálculo",
    "demonstrativo_evolucao_divida": "Demonstrativo de evolução da dívida",
    "tratamento_rejeicao": "Tratamento de rejeição",
    "tratamento_rejeicao_baixa_manual": "Tratamento de rejeição (baixa manual)",
}


def rotulo_manutencao(chave):
    """Converte a chave snake_case em rótulo legível (curado ou derivado)."""
    if chave in _LABELS:
        return _LABELS[chave]
    return chave.replace("_", " ").strip().capitalize()


def parse_coluna(nome):
    """Interpreta um nome de coluna.

    Retorna um dict com 'kind':
      - 'fixa'        : coluna fixa de identificação/volume/status
      - 'manutencao'  : {campo, manutencao, ambiente, rectype, rotulo, is_pj}
      - 'desconhecida': não reconhecida pela gramática
    """
    if nome in COLUNAS_FIXAS:
        return {"kind": "fixa", "nome": nome}

    if nome.startswith("quantidade_"):
        campo, resto = "quantidade", nome[len("quantidade_"):]
    elif nome.startswith("ultima_data_"):
        campo, resto = "ultima_data", nome[len("ultima_data_"):]
    else:
        return {"kind": "desconhecida", "nome": nome, "motivo": "prefixo de campo ausente"}

    partes = resto.split("_")
    idx_env = next((i for i, p in enumerate(partes) if p in _ENV), None)
    if idx_env is None or idx_env == 0:
        return {"kind": "desconhecida", "nome": nome, "motivo": "ambiente/manutenção ausente"}

    manutencao = "_".join(partes[:idx_env])
    ambiente = _ENV[partes[idx_env]]
    breakdown = partes[idx_env + 1:]

    rectype, rotulo, is_pj = None, "", False
    if breakdown:
        if breakdown[0] == "origem":
            rectype, rotulo = "origem", "_".join(breakdown[1:])
        elif breakdown[0] == "sigla":
            rectype, rotulo = "sigla", "_".join(breakdown[1:])
        else:
            rectype, rotulo = "outro", "_".join(breakdown)
        is_pj = "pj" in breakdown

    return {
        "kind": "manutencao",
        "nome": nome,
        "campo": campo,
        "manutencao": manutencao,
        "ambiente": ambiente,
        "rectype": rectype,
        "rotulo": rotulo,
        "is_pj": is_pj,
    }
