"""CLI: gera um relatório HTML standalone a partir de um CSV largo.

Uso:
    python src/gerar_relatorio.py <caminho_csv> [--saida <html>] [--template <html>]
                                  [--strict] [--quiet]

Contrato: specs/001-gerador-relatorio-mosaico/contracts/cli-interface.md
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path

from csv_reader import ler_csv, CSVVazioError
from dataset_builder import construir_dataset
from html_injector import gerar_html, AncoraNaoEncontrada

TEMPLATE_PADRAO = "template_html/Mosaico Custodias PF (standalone) (5).html"


def _caminho_saida_default(csv_path, agora):
    base = Path(csv_path)
    carimbo = agora.strftime("%Y%m%d-%H%M")
    return base.with_name(f"{base.stem}_relatorio_{carimbo}.html")


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Gera relatório HTML do mosaico de custódias a partir de um CSV."
    )
    parser.add_argument("csv", help="Caminho do CSV de entrada (somente leitura).")
    parser.add_argument("--saida", help="Caminho do HTML de saída (opcional).")
    parser.add_argument("--template", default=TEMPLATE_PADRAO, help="Template de referência.")
    parser.add_argument("--strict", action="store_true", help="Tratar avisos como erro (exit 3).")
    parser.add_argument("--quiet", action="store_true", help="Suprimir o resumo no stdout.")
    args = parser.parse_args(argv)

    csv_path = Path(args.csv)
    template_path = Path(args.template)

    if not csv_path.is_file():
        print(f"ERRO: CSV não encontrado: {csv_path}", file=sys.stderr)
        return 1
    if not template_path.is_file():
        print(f"ERRO: template não encontrado: {template_path}", file=sys.stderr)
        return 1

    try:
        header, linhas, avisos_csv = ler_csv(str(csv_path))
    except CSVVazioError as e:
        print(f"ERRO: {e}", file=sys.stderr)
        return 1

    dataset = construir_dataset(header, linhas, avisos_csv)

    try:
        template_html = template_path.read_text(encoding="utf-8")
        html = gerar_html(template_html, dataset)
    except AncoraNaoEncontrada as e:
        print(f"ERRO: ponto de injeção não encontrado no template ({e}). "
              f"O template é compatível?", file=sys.stderr)
        return 1

    saida = Path(args.saida) if args.saida else _caminho_saida_default(csv_path, datetime.now())
    if saida.exists():
        print(f"ERRO: arquivo de saída já existe (não será sobrescrito): {saida}", file=sys.stderr)
        return 2

    saida.write_text(html, encoding="utf-8")

    avisos = dataset.get("avisos", [])
    if not args.quiet:
        n_prod = len(dataset.get("produtos", []))
        n_tipos = len(dataset.get("tipos", []))
        custodias = sorted({p["custodia"] for p in dataset.get("produtos", [])})
        print("Relatório gerado:")
        print(f"  Arquivo : {saida}")
        ocultos = dataset.get("ocultos", [])
        print(f"  Produtos: {n_prod}")
        print(f"  Tipos de manutenção exibidos: {n_tipos}")
        if ocultos:
            print(f"  Tipos ocultos (sem solicitação): {len(ocultos)} — {', '.join(ocultos)}")
        print(f"  Custódias ({len(custodias)}): {', '.join(custodias)}")
        if avisos:
            print(f"  Avisos ({len(avisos)}):")
            for a in avisos:
                print(f"    - {a}")
        else:
            print("  Avisos: nenhum.")

    if args.strict and avisos:
        print(f"ERRO (--strict): {len(avisos)} aviso(s) encontrado(s).", file=sys.stderr)
        return 3

    return 0


if __name__ == "__main__":
    sys.exit(main())
