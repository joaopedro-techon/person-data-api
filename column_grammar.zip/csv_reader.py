"""Leitura do CSV largo (cabeçalho + uma linha por produto). Somente leitura."""

import csv

from column_grammar import COLUNAS_FIXAS


class CSVVazioError(Exception):
    pass


def ler_csv(caminho):
    """Lê o CSV e retorna (header, linhas, avisos).

    - header: lista de nomes de coluna.
    - linhas: lista de dicts {nome_coluna: valor_str}.
    - avisos: lista de strings (colunas fixas ausentes, cabeçalho duplicado).
    """
    avisos = []
    with open(caminho, "r", encoding="utf-8-sig", newline="") as fh:
        leitor = csv.reader(fh)
        try:
            header = next(leitor)
        except StopIteration:
            raise CSVVazioError("CSV sem cabeçalho.")
        header = [h.strip() for h in header]

        vistos = set()
        for h in header:
            if h in vistos:
                avisos.append(f"Cabeçalho duplicado: '{h}' (usada a última ocorrência).")
            vistos.add(h)

        linhas = []
        for bruto in leitor:
            if not any((c or "").strip() for c in bruto):
                continue  # ignora linhas totalmente vazias
            linha = {}
            for i, nome in enumerate(header):
                linha[nome] = bruto[i].strip() if i < len(bruto) else ""
            linhas.append(linha)

    for fixa in sorted(COLUNAS_FIXAS):
        if fixa not in header:
            avisos.append(f"Coluna fixa esperada ausente: '{fixa}'.")

    if not linhas:
        raise CSVVazioError("CSV sem linhas de produto (apenas cabeçalho).")

    return header, linhas, avisos
