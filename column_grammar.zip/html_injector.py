"""Injeção dos dados reais no template standalone (cirurgia mínima no build()).

Contrato: specs/001-gerador-relatorio-mosaico/contracts/build-data-contract.md

Estratégia: extrair o HTML interno do <script type="__bundler/template"> (JSON),
substituir o bloco de topo do build() por uma versão alimentada por __DATA__,
ajustar o nº de colunas e tornar dinâmicos a lista de disfunções e os recortes;
preservar todo o restante (motor de render, treemap, heatmaps, tiles).
"""

import json
import re


class AncoraNaoEncontrada(Exception):
    """Levantada quando um ponto de patch esperado não é encontrado no template."""


_RE_TEMPLATE = re.compile(
    r'(<script type="__bundler/template"[^>]*>)(.*?)(</script>)', re.S
)

# Âncoras do bloco de topo do build() (substituição contígua).
_ANCORA_INICIO = "seg = seg || 'TODOS';"
_ANCORA_FIM = "groups = groups.filter(g => g.rows.length > 0);"

_DISF_P1 = (
    '<p style="font-size:11.5px;color:#5C5450;line-height:1.4;">'
    '<strong style="color:#16233B;">Antecipação de Recebíveis · OD</strong> '
    '— responsabilidade PJ sendo atendida na esteira PF.</p>'
)
_DISF_P2 = (
    '<p style="font-size:11.5px;color:#5C5450;line-height:1.4;">'
    '<strong style="color:#16233B;">Crédito Rural · F8</strong> '
    '— produto fora do escopo da Custódia de Ativos PF.</p>'
)
_DISF_SCFOR = (
    '<sc-for list="{{ disfList }}" as="d" hint-placeholder-count="2">'
    '<p style="font-size:11.5px;color:#5C5450;line-height:1.4;">'
    '<strong style="color:#16233B;">{{ d.name }} · {{ d.cust }}</strong> '
    '— {{ d.text }}</p></sc-for>'
)


def _build_top_js(data_json):
    """Gera o JS do bloco de topo do build() consumindo __DATA__."""
    return (
        "seg = seg || 'TODOS';\n"
        "    const __DATA__ = " + data_json + ";\n"
        "    const fmt = n => n.toLocaleString('pt-BR');\n"
        "    const compact = n => { if (n >= 1000000) return (n/1000000).toFixed(1).replace('.',',')+' mi'; if (n >= 1000) return (n/1000).toFixed(1).replace('.',',')+' mil'; return String(n); };\n"
        "    const pctOf = (o,t) => { const v = o/t*100; return v < 0.1 ? '<0,1%' : v.toFixed(1).replace('.',',')+'%'; };\n"
        "    const cuStyle = cloud => cloud ? {bg:'#E8F0FD', color:'#2A6FDB', border:'#BFD6F7'} : {bg:'#EEF1F6', color:'#5C6878', border:'#E1E6EE'};\n"
        "    const types = __DATA__.tipos.map(t => ({ key:t.chave, name:t.rotulo }));\n"
        "    const prodByKey = {}; const custOrder = []; const custItems = {};\n"
        "    __DATA__.produtos.forEach(p => { prodByKey[p.custodia + '\\u0000' + p.nome] = p; if (!custItems[p.custodia]) { custItems[p.custodia] = []; custOrder.push(p.custodia); } custItems[p.custodia].push([p.nome, p.familia]); });\n"
        "    const typeMod = types.map(() => 0); const typeLeg = types.map(() => 0);\n"
        "    let total=0, contrCount=0, inativos=0, disfCount=0, modCellsTot=0, applCellsTot=0, totalOps=0;\n"
        "    const allRows = []; const heatAcc = {}; const heatFamAcc = {};\n"
        "    let groups = custOrder.map(code => {\n"
        "      const cloud = (code === 'GC');\n"
        "      let bandMod=0, bandAppl=0;\n"
        "      const segItems = custItems[code].filter(it => { const p = prodByKey[code + '\\u0000' + it[0]]; return seg === 'TODOS' || (p && p.classificacao === seg); });\n"
        "      const rows = segItems.map(it => {\n"
        "        const name = it[0], fam = it[1]; const p = prodByKey[code + '\\u0000' + name];\n"
        "        const isDisf = !!p.isDisf; if (isDisf) disfCount++;\n"
        "        total++; if (p.contr) contrCount++; if (!p.ativo) inativos++;\n"
        "        const ops = p.ops || 0; totalOps += ops;\n"
        "        let rowMod = 0, rowLeg = 0;\n"
        "        const cells = types.map((t, i) => {\n"
        "          const m = p.manut[t.key];\n"
        "          const qPF = m ? m.modPF : 0, qPJ = m ? m.modPJ : 0, qLeg = m ? m.leg : 0;\n"
        "          const tot = qPF + qPJ + qLeg;\n"
        "          if (tot === 0) { if (!isDisf) { if (!heatAcc[code]) heatAcc[code] = types.map(() => ({m:0,l:0,na:0})); heatAcc[code][i].na += 1; } return { na:true, fill:false, modPctLabel:'0%', border:'1px dashed #DBE1EA', bg:'#F7F9FC', tipTitle:name+' \\u00b7 '+t.name, tipMod:'', tipLeg:'', tipNa:'1', tipRec:'' }; }\n"
        "          const qMod = qPF + qPJ;\n"
        "          if (!isDisf) { bandAppl++; applCellsTot++; const fr = qMod/tot; bandMod += fr; modCellsTot += fr; }\n"
        "          rowMod += qMod; rowLeg += qLeg; typeMod[i] += qMod; typeLeg[i] += qLeg;\n"
        "          if (!isDisf) { if (!heatAcc[code]) heatAcc[code] = types.map(() => ({m:0,l:0,na:0})); heatAcc[code][i].m += qMod; heatAcc[code][i].l += qLeg; if (!heatFamAcc[fam]) heatFamAcc[fam] = types.map(() => ({m:0,l:0,na:0})); heatFamAcc[fam][i].m += qMod; heatFamAcc[fam][i].l += qLeg; }\n"
        "          let pfPct = Math.round(qPF/tot*100), pjPct = Math.round(qPJ/tot*100); let legPct = 100 - pfPct - pjPct; if (legPct < 0) legPct = 0;\n"
        "          const tipMod = qMod > 0 ? (compact(qMod) + ' \\u00b7 ' + (m.dataMod || '\\u2014') + (qPJ > 0 ? ' \\u00b7 inclui moderno PJ' : '')) : '';\n"
        "          const tipLeg = qLeg > 0 ? (compact(qLeg) + ' \\u00b7 ' + (m.dataLeg || '\\u2014')) : '';\n"
        "          const recs = (m && m.recortes) ? m.recortes.filter(r => (r.qtd && r.qtd > 0) || r.data) : [];\n"
        "          const tipRec = recs.map(r => (r.tipo + ' ' + r.rotulo + ' [' + r.ambiente + (r.pj ? '/PJ' : '') + ']: ' + (r.qtd != null ? compact(r.qtd) : '0') + (r.data ? (' \\u00b7 ' + r.data) : ''))).join('\\n');\n"
        "          return { na:false, fill:true, bg:'transparent', border:'none', pfW:pfPct+'%', pjW:pjPct+'%', pfShow:pfPct>=38, pjShow:pjPct>=38, legShow:legPct>=38, tipTitle:name+' \\u00b7 '+t.name, tipMod:tipMod, tipLeg:tipLeg, tipNa:'', tipRec:tipRec };\n"
        "        });\n"
        "        const modPct = (rowMod + rowLeg) ? Math.round(rowMod/(rowMod+rowLeg)*100) : 0;\n"
        "        const row = { name, isDisf, cust: code, resp: p.responsabilidade || '', disfTitle: 'Disfun\\u00e7\\u00e3o \\u2014 responsabilidade ' + (p.responsabilidade || '\\u2014'), nameColor: isDisf ? '#B5271A' : '#16233B', rowBg: isDisf ? '#FDF4F2' : '#FFFFFF', cells, last: p.last || '\\u2014', lastColor: p.lastStale ? '#D23B2C' : '#65718A', lastContr: p.lastContr || '\\u2014', lastContrColor: p.contr ? '#16233B' : '#9AA4B6', ativoLabel: p.ativo ? 'Sim' : 'N\\u00e3o', ativoBg: p.ativo ? '#EEF1F6' : '#FDECEA', ativoColor: p.ativo ? '#5C6878' : '#C23A2B', ops, opsLabel: fmt(ops), opsAtv: fmt(p.opsAtv||0), opsCanc: fmt(p.opsCanc||0), opsLiq: fmt(p.opsLiq||0), fam, solicMod: rowMod, solicLeg: rowLeg, solicTot: rowMod + rowLeg, modPct, code: p.codigo || '', modPctLabel: modPct + '%', legPctLabel: (100 - modPct) + '%' };\n"
        "        allRows.push(row); return row;\n"
        "      });\n"
        "      const groupOps = rows.reduce((s,r) => s + r.ops, 0) || 1;\n"
        "      rows.forEach(r => { r.pctLabel = pctOf(r.ops, groupOps); });\n"
        "      const cs = cuStyle(cloud);\n"
        "      const avg = bandAppl ? Math.round(bandMod/bandAppl*100) : 0;\n"
        "      const famMap = {}; const famOrder = [];\n"
        "      rows.forEach(r => { if (!famMap[r.fam]) { famMap[r.fam] = []; famOrder.push(r.fam); } famMap[r.fam].push(r); });\n"
        "      const famGroups = famOrder.map(f => { const frs = famMap[f]; const fOps = frs.reduce((s,r) => s + r.ops, 0); const fMod = frs.reduce((s,r) => s + r.solicMod, 0); const fTot = frs.reduce((s,r) => s + r.solicTot, 0); return { fam:f, rows:frs, prodCount:frs.length, opsLabel: compact(fOps), modLabel: (fTot ? Math.round(fMod/fTot*100) : 0) + '%' }; });\n"
        "      return { code: code, plat: cloud ? 'Cloud AWS' : 'Mainframe', platBg: cloud ? '#E8F0FD' : '#EEF1F6', platColor: cloud ? '#2A6FDB' : '#7E8AA0', chipBg: cloud ? '#E8F0FD' : '#FFFFFF', chipBorder: cs.border, chipColor: cs.color, bandBg: cloud ? '#F7FAFF' : '#FAFBFD', bandBorder: cloud ? '#DCEAFB' : '#EAEEF3', prodCount: rows.length, avgLabel: avg + '%', groupOps, opsLabel: fmt(groupOps), opsPctLabel: '', rows, famGroups };\n"
        "    });\n"
        "    groups.forEach(g => { g.opsPctLabel = pctOf(g.groupOps, totalOps || 1); });\n"
        "    const disfList = allRows.filter(r => r.isDisf).map(r => ({ name: r.name, cust: r.cust, text: 'responsabilidade ' + (r.resp || '\\u2014') + ' atendida na esteira PF' }));\n"
        "    groups = groups.filter(g => g.rows.length > 0);"
    )


def _replace_once(texto, antigo, novo, label):
    if antigo not in texto:
        raise AncoraNaoEncontrada(label)
    return texto.replace(antigo, novo, 1)


def _replace_all(texto, antigo, novo, label):
    if antigo not in texto:
        raise AncoraNaoEncontrada(label)
    return texto.replace(antigo, novo)


def _patch_inner(inner, dataset):
    n_tipos = len(dataset.get("tipos", []))
    data_json = json.dumps(dataset, ensure_ascii=False).replace("</", "<\\/")

    # 1) Bloco de topo do build(): substituir do _ANCORA_INICIO até o fim de _ANCORA_FIM.
    i = inner.find(_ANCORA_INICIO)
    if i == -1:
        raise AncoraNaoEncontrada("build:inicio")
    j = inner.find(_ANCORA_FIM, i)
    if j == -1:
        raise AncoraNaoEncontrada("build:fim")
    j += len(_ANCORA_FIM)
    inner = inner[:i] + _build_top_js(data_json) + inner[j:]

    # 2) Nº de colunas de manutenção (grid dinâmico). Mantém os rótulos na
    #    HORIZONTAL enquanto couberem na largura (~14 colunas a 58px); acima
    #    disso usa cabeçalhos VERTICAIS + colunas estreitas.
    vertical = n_tipos > 14
    grid_antigo = "repeat(8,minmax(58px,1fr))"
    if grid_antigo not in inner:
        raise AncoraNaoEncontrada("grid-template-columns")
    min_col = "26px" if vertical else "58px"
    inner = inner.replace(grid_antigo, "repeat(%d,minmax(%s,1fr))" % (n_tipos, min_col))

    if vertical:
        # 2a) Rótulos do cabeçalho na vertical (ellipsis + title para os mais longos).
        inner = _replace_once(
            inner,
            '<span style="font-size:9.5px;font-weight:700;color:#65718A;text-align:center;line-height:1.15;">{{ t.name }}</span>',
            '<span title="{{ t.name }}" style="font-size:9px;font-weight:700;color:#65718A;'
            'writing-mode:vertical-rl;transform:rotate(180deg);white-space:nowrap;'
            'height:172px;line-height:1;overflow:hidden;text-overflow:ellipsis;'
            'align-self:end;justify-self:center;">{{ t.name }}</span>',
            "header-types-vertical",
        )
        # 2b) A banda de custódia gruda abaixo do cabeçalho (agora mais alto).
        inner = _replace_once(
            inner, "position:sticky;top:44px;", "position:sticky;top:190px;", "band-sticky-top"
        )

    # 2c) Mapas de calor (abas Calor): mesmos N tipos como colunas. Ajustar a
    #     contagem do grid (senão quebra), a largura mínima e os cabeçalhos.
    inner = _replace_all(
        inner, "148px repeat(8,1fr) 86px", "148px repeat(%d,1fr) 86px" % n_tipos, "heat-grid-cust"
    )
    inner = _replace_all(
        inner, "178px repeat(8,1fr) 86px", "178px repeat(%d,1fr) 86px" % n_tipos, "heat-grid-fam"
    )
    min_w = (240 + n_tipos * 34) if vertical else max(980, 234 + n_tipos * 64)
    inner = _replace_all(inner, "min-width:980px;", "min-width:%dpx;" % min_w, "heat-min-width")
    if vertical:
        inner = _replace_all(
            inner,
            '<div style="font-size:9.5px;font-weight:700;color:#46546B;line-height:1.15;min-height:24px;display:flex;align-items:flex-end;justify-content:center;">{{ c.name }}</div>',
            '<div title="{{ c.name }}" style="font-size:9px;font-weight:700;color:#46546B;'
            'writing-mode:vertical-rl;transform:rotate(180deg);white-space:nowrap;height:150px;'
            'line-height:1;overflow:hidden;text-overflow:ellipsis;margin:0 auto;">{{ c.name }}</div>',
            "heat-header-vertical",
        )

    # 3) Rolagem horizontal na seção da tabela (acomoda N colunas).
    inner = _replace_once(
        inner,
        'padding:20px 22px 18px;box-shadow:0 1px 3px rgba(22,35,59,.05);">',
        'padding:20px 22px 18px;box-shadow:0 1px 3px rgba(22,35,59,.05);overflow-x:auto;">',
        "table-section-overflow",
    )

    # 4) KPI de disfunções (estava hardcoded em 2).
    inner = _replace_once(
        inner,
        "custodias: b.mekko.length, disf: 2,",
        "custodias: b.mekko.length, disf: b.kpi.disf,",
        "kpi-disf-hardcoded",
    )

    # 5) Expor disfList: no return do build() e no contexto do renderVals().
    inner = _replace_once(
        inner,
        "return { types, groups, kpi, custodyTiles,",
        "return { types, groups, kpi, disfList, custodyTiles,",
        "build-return-disfList",
    )
    inner = _replace_once(
        inner,
        "kpi: b.kpi, func: b.func,",
        "kpi: b.kpi, disfList: b.disfList, func: b.func,",
        "context-disfList",
    )

    # 6) Bloco de disfunções: trocar os 2 <p> fixos por sc-for dinâmico.
    inner = _replace_once(inner, _DISF_P1, _DISF_SCFOR, "disf-p1")
    inner = _replace_once(inner, _DISF_P2, "", "disf-p2")

    # 7) Recortes no tooltip: atributo na célula + render.
    inner = _replace_once(
        inner,
        'data-tip-na="{{ c.tipNa }}"',
        'data-tip-na="{{ c.tipNa }}" data-tip-rec="{{ c.tipRec }}"',
        "cell-tip-rec-attr",
    )
    inner = _replace_once(
        inner,
        "if (leg) h += block('Legado (mainframe)', '#8A93A6', leg);",
        "if (leg) h += block('Legado (mainframe)', '#8A93A6', leg);\n"
        "      const rec = el.getAttribute('data-tip-rec'); if (rec) h += \"<div style='font-size:10px;color:#9AA4B6;margin-top:8px;padding-top:8px;border-top:1px solid #EEF1F5;white-space:pre-line;'>\"+rec+\"</div>\";",
        "tooltip-rec-render",
    )

    return inner


def gerar_html(template_html, dataset):
    """Retorna o HTML standalone final com os dados reais injetados."""
    m = _RE_TEMPLATE.search(template_html)
    if not m:
        raise AncoraNaoEncontrada("__bundler/template")
    inner = json.loads(m.group(2))
    inner = _patch_inner(inner, dataset)
    novo_conteudo = json.dumps(inner, ensure_ascii=False).replace("</", "<\\/")
    return template_html[:m.start(2)] + novo_conteudo + template_html[m.end(2):]
