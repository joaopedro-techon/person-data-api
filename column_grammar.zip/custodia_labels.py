"""Dicionário estático de custódias (código -> descrição / plataforma).

Rótulo (não dado). Reproduz o `descMap` do template de referência. O HTML gerado
usa o `descMap` embutido no próprio template; este módulo existe para
documentação/auditoria e para os testes (FR-007a).

Código desconhecido => sem descrição (o relatório exibe apenas o código).
"""

DESCRICAO = {
    "SF": "Crédito Direto e Empréstimos",
    "F5": "Consignado",
    "SO": "Imobiliário",
    "F8": "Veículos e Rural",
    "OD": "Cheque e Limites",
    "GC": "Crédito Digital",
    "CL": "Cartão e Limites",
    "SF3": "Crédito Direto III",
    "SF4": "Crédito Direto IV",
}

# Apenas GC roda em nuvem (AWS) no template de referência.
CLOUD = {"GC"}


def descricao(codigo):
    return DESCRICAO.get(codigo, "")


def is_cloud(codigo):
    return codigo in CLOUD
